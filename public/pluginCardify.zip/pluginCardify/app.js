'use strict';

$(document).ready(function () {
  $('.container-img').cardify();
});