'use strict';

$(document).ready(function () {
  $('.container-img').cardify();
  $('figure').addClass('col-xs-12 col-sm-6 col-lg-4');
  $('img').addClass('img-responsive images');
});